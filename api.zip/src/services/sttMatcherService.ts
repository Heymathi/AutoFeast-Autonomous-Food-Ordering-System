import { Language, FoodItem } from '../types';
import { CrossScriptPhoneticMatcher } from './crossScriptPhoneticMatcher';
import { INDIAN_FOOD_CATALOG } from '../data/indianFoodCatalog';
import { FuzzyMatchEngine } from './fuzzyMatchService';
import { FUZZY_CONFIG, CANONICAL_FOOD_ALIASES } from '../config/fuzzyConfig';
import { UserAliasService } from './userAliasService';

export type ConfirmationIntent = 'YES' | 'NO' | 'UNKNOWN';
export type ControlCommandIntent = 'YES' | 'NO' | 'NEXT' | 'BACK' | 'CANCEL' | 'ORDER_NOW' | 'SCHEDULE' | 'UNKNOWN';

export interface MatchResult<T = string> {
  isMatched: boolean;
  matchedValue: T | null;
  confidence: number;
  needsClarification: boolean;
  bestCandidate?: T;
  top3Candidates?: T[];
  clarificationPrompt?: string;
  matchedTranscript?: string;
  quantity?: number;
  isGenericCategory?: boolean;
}

export interface MultiItemMatchResult {
  items: Array<{ foodItem: FoodItem; quantity: number }>;
  unmatchedSegments: string[];
  confidence: number;
  needsClarification: boolean;
  clarificationPrompt?: string;
  top3Candidates?: FoodItem[];
}

export const CONFIRMATION_VOCABULARY: any = {
  YES: {
    en: ['yes', 'yeah', 'yep', 'sure', 'ok', 'okay', 'confirm', 'proceed', 'do it', 'correct', 'right', 'accept', 'allow'],
    ta: ['ஆம்', 'ஆமாம்', 'சரி', 'ஆமா', 'செய்', 'வேண்டும்', 'உறுதி', 'அனுமதி', 'ஓகே', 'கொடு', 'aama', 'aamam', 'sari', 'seri', 'kodu', 'aam'],
    hi: ['हाँ', 'जी हाँ', 'हाँजी', 'ठीक', 'ठीक है', 'करो', 'हाँ करो', 'मंजूर', 'अनुमति', 'haan', 'sahi', 'ji haan']
  },
  NO: {
    en: ['no', 'nope', 'cancel', 'stop', 'deny', 'dont', "don't", 'reject', 'decline', 'never', 'nah'],
    ta: ['இல்லை', 'இல்ல', 'வேண்டாம்', 'வேணாம்', 'ரத்து', 'மறு', 'வேண்டாதீங்க', 'மனா', 'illa', 'illai', 'vendam', 'venam', 'vaendaam'],
    hi: ['नहीं', 'ना', 'मना', 'कैंसल', 'नहीं चाहिए', 'रद्द', 'मना करें', 'nahi', 'naa', 'nahin']
  },
  NEXT: {
    en: ['next', 'forward', 'continue', 'skip'],
    ta: ['அடுத்தது', 'அடுத்து', 'முன்னேறு'],
    hi: ['अगला', 'आगे', 'जारी रखें']
  },
  BACK: {
    en: ['back', 'previous', 'go back'],
    ta: ['பின்னாடி', 'திரும்பு', 'முந்தைய'],
    hi: ['पीछे', 'वापस', 'पिछला']
  },
  CANCEL: {
    en: ['cancel', 'exit', 'close'],
    ta: ['ரத்து', 'மூடு', 'வெளியேறு'],
    hi: ['ரத்து', 'बंद', 'बाहर']
  },
  ORDER_NOW: {
    en: ['order now', 'instant', 'order', 'now', 'buy now'],
    ta: ['இப்போதே ஆர்டர் செய்', 'இப்போதே', 'இப்போ', 'உடனடி', 'ஆர்டர் செய்', 'ஆர்டர் பண்ணு'],
    hi: ['अभी ऑर्डर करें', 'अभी', 'तुरंत', 'ऑर्डर करें']
  },
  SCHEDULE: {
    en: ['schedule', 'later', 'schedule for later', 'set time'],
    ta: ['அட்டவணைப்படுத்து', 'அட்டவணை', 'திட்டமிடு', 'பிறகு', 'பின்னர்', 'அப்புறம்'],
    hi: ['शेड्यूल करें', 'शेड्यूल', 'बाद में', 'समय सेट करें']
  }
};

export const DURATION_VOCABULARY = {
  'today_only': ['today alone', 'today only', 'just today', '1 day', 'one day', 'for today', 'இன்று மட்டும்', 'இன்னைக்கு மட்டும்', 'ஒரு நாள்', 'இன்று', 'केवल आज', 'आज ही', 'आज बस', 'एक दिन'],
  '1_week': ['1 week', 'one week', '7 days', 'seven days', '1 வாரம்', 'ஒரு வாரம்', '1 வாரத்திற்கு', 'ஒரு வாரத்திற்கு', '7 நாட்கள்', '1 हफ्ता', 'एक हफ्ता', '7 दिन'],
  '1_month': ['1 month', 'one month', '30 days', 'thirty days', '1 மாதம்', 'ஒரு மாதம்', '1 மாதத்திற்கு', 'ஒரு மாதத்திற்கு', '30 நாட்கள்', '1 महीना', 'एक महीना', '30 दिन'],
  '3_months': ['3 months', 'three months', '90 days', '3 மாதம்', '3 மாதங்கள்', '3 மாதத்திற்கு', '90 நாட்கள்', '3 महीने', 'तीन महीने', '90 दिन'],
  'custom': ['custom date range', 'custom range', 'custom date', 'custom', 'date range', 'சுயவிருப்ப தேதி', 'தேதி வரம்பு', 'குறிப்பிட்ட தேதி', 'கஸ்டம்', 'கஸ்டம் தேதி', 'கஸ்டம் ரேஞ்ச்', 'कस्टम तिथि सीमा', 'कस्टम तारीख', 'कस्टम रेट', 'कस्टम'],
  'indefinite': ['indefinite', 'forever', 'always', 'continuous', 'தொடர்ச்சியாக', 'எப்போதும்', 'வரம்பில்லாமல்', 'हमेशा', 'लगातार']
};

export const EVERY_DAY_VOCABULARY = [
  'every day', 'everyday', 'daily', 'all days', 'every single day',
  'தினமும்', 'ஒவ்வொரு நாளும்', 'எல்லா நாளும்', 'தினசரி', 'தினமுமே',
  'रोजाना', 'हर रोज', 'हर दिन', 'प्रतिदिन', 'रोज'
];

export const WEEKDAY_MAP: { [key: string]: string[] } = {
  'Mon': ['monday', 'mondays', 'mon', 'திங்கள்', 'திங்கட்கிழமை', 'tingal', 'somvar', 'सोमवार'],
  'Tue': ['tuesday', 'tuesdays', 'tue', 'செவ்வாய்', 'செவ்வாய்க்கிழமை', 'sevvai', 'mangalvar', 'मंगलवार'],
  'Wed': ['wednesday', 'wednesdays', 'wed', 'புதன்', 'புதன்கிழமை', 'budhan', 'budhvar', 'बुधवार'],
  'Thu': ['thursday', 'thursdays', 'thu', 'வியாழன்', 'வியாழக்கிழமை', 'vyazhan', 'guruvar', 'गुरुवार'],
  'Fri': ['friday', 'fridays', 'fri', 'வெள்ளி', 'வெள்ளிக்கிழமை', 'velli', 'shukravar', 'शुक्रवार'],
  'Sat': ['saturday', 'saturdays', 'sat', 'சனி', 'சனிக்கிழமை', 'sani', 'shanivar', 'शनिवार'],
  'Sun': ['sunday', 'sundays', 'sun', 'ஞாயிறு', 'ஞாயிற்றுக்கிழமை', 'nyayiru', 'ravivar', 'रविवार']
};

export const LANGUAGE_VOCABULARY = {
  ta: ['tamil', 'தமிழ்', 'tamizh', 'thamil', 'தமிள்', 'ஒன்று', 'ஒன்னு', 'ஒரு', '1'],
  en: ['english', 'இங்கிலீஷ்', 'इंग्लिश', 'inglish', 'ஆங்கிலம்', 'ஆங்கில', 'இரண்டு', 'ரெண்டு', '2'],
  hi: ['hindi', 'हिंदी', 'hindhi', 'हिन्दी', 'இந்தி', 'ஹிந்தி', 'ஹிந்தீ', 'तीन', '3']
};

const FILLER_WORDS = [
  'i want', 'order', 'please', 'give me', 'bring me', 'add', 'get me',
  'venum', 'vaenum', 'podu', 'kudu', 'kodu', 'panno', 'kudungga', 'vaanggu',
  'chahiye', 'karo', 'laya', 'do', 'dedo', 'mujhe', 'enaku', 'enakku', 'order karo'
];

const GENERIC_CATEGORY_KEYWORDS: { [key: string]: string[] } = {
  'idli': ['idli', 'idly', 'iddli', 'italy', 'eatly', 'itli', 'edli', 'இட்லி', 'இட்டலி', 'इडली'],
  'dosa': ['dosa', 'dosai', 'dhosai', 'dosha', 'doser', 'தோசை', 'डोसा'],
  'biryani': ['biryani', 'biriyani', 'briyani', 'beer yani', 'berryani', 'பிரியாணி', 'बिरयानी'],
  'parotta': ['parotta', 'parota', 'barota', 'பரோட்டா', 'परोटा']
};

export class SttMatcherService {
  private static toCandidateList(input: string | string[]): string[] {
    const list = Array.isArray(input) ? input : [input];
    return list
      .filter((s): s is string => typeof s === 'string' && s.trim().length > 0)
      .map(s => s.toLowerCase().trim());
  }

  public static extractQuantityAndCleanPhrase(text: string): { quantity: number; cleanPhrase: string } {
    let clean = (text || '').toLowerCase().trim();
    let quantity = 1;

    const numMatch = clean.match(/\b(\d+)\b/);
    if (numMatch) {
      const parsed = parseInt(numMatch[1], 10);
      if (parsed > 0 && parsed <= 99) {
        quantity = parsed;
        clean = clean.replace(/\b\d+\b/g, '').trim();
      }
    } else {
      if (/\b(rendu|ரெண்டு|இரண்டு|do|दो|two|2)\b/i.test(clean)) {
        quantity = 2;
        clean = clean.replace(/\b(rendu|ரெண்டு|இரண்டு|do|दो|two|2)\b/gi, '').trim();
      } else if (/\b(moonu|மூணு|மூன்று|teen|तीन|three|3)\b/i.test(clean)) {
        quantity = 3;
        clean = clean.replace(/\b(moonu|மூணு|மூன்று|teen|तीन|three|3)\b/gi, '').trim();
      } else if (/\b(naangu|நான்கு|char|चार|four|4)\b/i.test(clean)) {
        quantity = 4;
        clean = clean.replace(/\b(naangu|நான்கு|char|चार|four|4)\b/gi, '').trim();
      } else if (/\b(ainthu|ஐந்து|paanch|पांच|five|5)\b/i.test(clean)) {
        quantity = 5;
        clean = clean.replace(/\b(ainthu|ஐந்து|paanch|पांच|five|5)\b/gi, '').trim();
      } else if (/\b(one|ek|ஒரு|ஒன்று|ஒன்னு|1)\b/i.test(clean)) {
        quantity = 1;
        clean = clean.replace(/\b(one|ek|ஒரு|ஒன்று|ஒன்னு|1)\b/gi, '').trim();
      }
    }

    for (const filler of FILLER_WORDS) {
      const reg = new RegExp(`\\b${filler}\\b`, 'gi');
      clean = clean.replace(reg, '').trim();
    }

    clean = clean.replace(/\s+/g, ' ').trim();
    return { quantity, cleanPhrase: clean || text };
  }

  public static matchFoodItem(
    transcripts: string | string[],
    catalog: FoodItem[] = INDIAN_FOOD_CATALOG,
    language: Language = 'en'
  ): FoodItem | null {
    const res = this.matchCatalogItem(transcripts, catalog, language);
    return res.isMatched ? res.matchedValue : (res.needsClarification ? res.bestCandidate || null : null);
  }

  public static matchConfirmation(
    transcripts: string | string[],
    language: Language = 'en'
  ): MatchResult<ConfirmationIntent> {
    const candidates = this.toCandidateList(transcripts);
    if (candidates.length === 0) {
      return { isMatched: false, matchedValue: 'UNKNOWN', confidence: 0, needsClarification: false };
    }

    let bestIntent: ConfirmationIntent = 'UNKNOWN';
    let maxScore = 0;
    let matchedTranscript = '';

    const yesWords = [
      ...CONFIRMATION_VOCABULARY.YES.en,
      ...CONFIRMATION_VOCABULARY.YES.ta,
      ...CONFIRMATION_VOCABULARY.YES.hi
    ];

    const noWords = [
      ...CONFIRMATION_VOCABULARY.NO.en,
      ...CONFIRMATION_VOCABULARY.NO.ta,
      ...CONFIRMATION_VOCABULARY.NO.hi
    ];

    for (const text of candidates) {
      for (const word of yesWords) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, word);
        if (score > maxScore) {
          maxScore = score;
          bestIntent = 'YES';
          matchedTranscript = text;
        }
      }
      for (const word of noWords) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, word);
        if (score > maxScore) {
          maxScore = score;
          bestIntent = 'NO';
          matchedTranscript = text;
        }
      }
    }

    if (maxScore >= FUZZY_CONFIG.highConfidence) {
      return {
        isMatched: true,
        matchedValue: bestIntent,
        confidence: maxScore,
        needsClarification: false,
        matchedTranscript
      };
    }

    if (maxScore >= FUZZY_CONFIG.mediumConfidence && bestIntent !== 'UNKNOWN') {
      const prompt = language === 'ta'
        ? `உங்களின் பதில் "${bestIntent === 'YES' ? 'ஆம்' : 'இல்லை'}" என்பதா?`
        : language === 'hi'
        ? `क्या आपका मतलब "${bestIntent === 'YES' ? 'हाँ' : 'नहीं'}" था?`
        : `Did you mean "${bestIntent === 'YES' ? 'Yes' : 'No'}"?`;

      return {
        isMatched: false,
        matchedValue: 'UNKNOWN',
        confidence: maxScore,
        needsClarification: true,
        bestCandidate: bestIntent,
        clarificationPrompt: prompt,
        matchedTranscript
      };
    }

    return {
      isMatched: false,
      matchedValue: 'UNKNOWN',
      confidence: maxScore,
      needsClarification: false,
      matchedTranscript
    };
  }

  public static matchVocabulary<T extends string>(
    transcripts: string | string[],
    vocabList: T[],
    language: Language = 'en'
  ): MatchResult<T> {
    const candidates = this.toCandidateList(transcripts);
    let bestVal: T | null = null;
    let maxScore = 0;

    for (const text of candidates) {
      for (const target of vocabList) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, target);
        if (score > maxScore) {
          maxScore = score;
          bestVal = target;
        }
      }
    }

    if (maxScore >= 0.50 && bestVal) {
      return { isMatched: true, matchedValue: bestVal, confidence: maxScore, needsClarification: false };
    }
    return { isMatched: false, matchedValue: null, confidence: maxScore, needsClarification: false };
  }

  public static matchLanguageChoice(transcripts: string | string[]): MatchResult<Language> {
    const candidates = this.toCandidateList(transcripts);
    let matched: Language | null = null;
    let maxScore = 0;

    for (const text of candidates) {
      for (const w of LANGUAGE_VOCABULARY.ta) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, w);
        if (score > maxScore) { maxScore = score; matched = 'ta'; }
      }
      for (const w of LANGUAGE_VOCABULARY.en) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, w);
        if (score > maxScore) { maxScore = score; matched = 'en'; }
      }
      for (const w of LANGUAGE_VOCABULARY.hi) {
        const score = FuzzyMatchEngine.calculateMatchScore(text, w);
        if (score > maxScore) { maxScore = score; matched = 'hi'; }
      }
    }

    const confidence = maxScore;
    const isMatched = maxScore >= FUZZY_CONFIG.mediumConfidence && !!matched;
    const needsClarification = maxScore >= FUZZY_CONFIG.mediumConfidence && maxScore < FUZZY_CONFIG.highConfidence;

    return {
      isMatched,
      matchedValue: matched,
      confidence,
      needsClarification
    };
  }

  public static matchDaysChoice(
    transcripts: string | string[],
    language: Language = 'en'
  ): { isEveryDay: boolean; selectedDays: string[]; isMatched?: boolean; matchedValue?: any } {
    const candidates = this.toCandidateList(transcripts);
    let isEveryDay = false;
    const selectedDays: string[] = [];

    for (const text of candidates) {
      for (const ev of EVERY_DAY_VOCABULARY) {
        if (FuzzyMatchEngine.calculateMatchScore(text, ev) >= 0.65) {
          isEveryDay = true;
          return {
            isEveryDay: true,
            selectedDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            isMatched: true,
            matchedValue: { isEveryDay: true, selectedDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] }
          };
        }
      }
      for (const [dayKey, words] of Object.entries(WEEKDAY_MAP)) {
        for (const w of words) {
          if (FuzzyMatchEngine.calculateMatchScore(text, w) >= 0.65) {
            if (!selectedDays.includes(dayKey)) selectedDays.push(dayKey);
          }
        }
      }
    }

    return {
      isEveryDay,
      selectedDays,
      isMatched: selectedDays.length > 0,
      matchedValue: { isEveryDay, selectedDays }
    };
  }

  public static matchDurationChoice(
    transcripts: string | string[],
    language: Language = 'en'
  ): MatchResult<string> & string {
    const candidates = this.toCandidateList(transcripts);
    let matchedDur: string | null = null;
    let maxScore = 0;

    for (const text of candidates) {
      for (const [durKey, words] of Object.entries(DURATION_VOCABULARY)) {
        for (const w of words) {
          const score = FuzzyMatchEngine.calculateMatchScore(text, w);
          if (score >= 0.60 && score > maxScore) {
            maxScore = score;
            matchedDur = durKey;
          }
        }
      }
    }

    const res: any = matchedDur || '1_week';
    res.isMatched = !!matchedDur;
    res.matchedValue = matchedDur;
    res.confidence = maxScore;
    res.needsClarification = false;
    return res;
  }

  public static parseSpokenDate(transcripts: string | string[]): string | null {
    return null;
  }

  public static isGenericCategoryPhrase(cleanPhrase: string): { isGeneric: boolean; categoryKey: string | null } {
    const clean = cleanPhrase.toLowerCase().trim();
    for (const [catKey, aliasList] of Object.entries(GENERIC_CATEGORY_KEYWORDS)) {
      if (aliasList.some(alias => clean === alias || clean === `a ${alias}` || clean === `some ${alias}`)) {
        return { isGeneric: true, categoryKey: catKey };
      }
    }
    return { isGeneric: false, categoryKey: null };
  }

  public static checkRestrictedFoodInterception(
    query: string,
    restrictedCatalogItems: FoodItem[]
  ): { isRestricted: boolean; matchedItem: FoodItem | null; score: number } {
    if (!query || restrictedCatalogItems.length === 0) return { isRestricted: false, matchedItem: null, score: 0 };
    const { cleanPhrase } = this.extractQuantityAndCleanPhrase(query);

    let maxScore = 0;
    let matchedItem: FoodItem | null = null;

    for (const item of restrictedCatalogItems) {
      const namesToCompare = [
        item.name,
        item.id,
        item.nativeNames?.en || '',
        item.nativeNames?.ta || '',
        item.nativeNames?.hi || ''
      ].filter(Boolean);

      const aliasEntry = CANONICAL_FOOD_ALIASES.find(a => a.id === item.id || item.name.toLowerCase().includes(a.canonicalName.toLowerCase()));
      if (aliasEntry) namesToCompare.push(...aliasEntry.aliases);

      for (const targetName of namesToCompare) {
        const score = FuzzyMatchEngine.calculateMatchScore(cleanPhrase, targetName);
        if (score > maxScore) {
          maxScore = score;
          matchedItem = item;
        }
      }
    }

    if (maxScore >= FUZZY_CONFIG.restrictedThreshold && matchedItem) {
      return { isRestricted: true, matchedItem, score: maxScore };
    }

    return { isRestricted: false, matchedItem: null, score: maxScore };
  }

  public static matchCatalogItem(
    transcripts: string | string[],
    catalog: FoodItem[] = INDIAN_FOOD_CATALOG,
    language: Language = 'en',
    userId: string = 'default_user'
  ): MatchResult<FoodItem> {
    const rawCandidates = this.toCandidateList(transcripts);
    if (rawCandidates.length === 0 || catalog.length === 0) {
      return {
        isMatched: false,
        matchedValue: null,
        confidence: 0,
        needsClarification: false,
        top3Candidates: catalog.slice(0, 3)
      };
    }

    const primaryExt = this.extractQuantityAndCleanPhrase(rawCandidates[0]);
    const globalQuantity = primaryExt.quantity;

    const genericCheck = this.isGenericCategoryPhrase(primaryExt.cleanPhrase);

    const candidateScores: Array<{
      foodItem: FoodItem;
      score: number;
      rawText: string;
      cleanText: string;
    }> = [];

    rawCandidates.forEach((rawText, index) => {
      const rankWeight = Math.max(0.65, 1 - index * 0.07);
      const { cleanPhrase } = this.extractQuantityAndCleanPhrase(rawText);

      const learnedTargetId = UserAliasService.findLearnedTargetId(cleanPhrase, userId);
      if (learnedTargetId) {
        const learnedItem = catalog.find(item => item.id === learnedTargetId);
        if (learnedItem) {
          candidateScores.push({
            foodItem: learnedItem,
            score: 0.98 * rankWeight,
            rawText,
            cleanText: cleanPhrase
          });
        }
      }

      catalog.forEach(item => {
        let maxItemScore = 0;

        const namesToCompare = [
          item.name,
          item.id,
          item.nativeNames?.en || '',
          item.nativeNames?.ta || '',
          item.nativeNames?.hi || ''
        ].filter(Boolean);

        const aliasEntry = CANONICAL_FOOD_ALIASES.find(a => a.id === item.id || item.name.toLowerCase().includes(a.canonicalName.toLowerCase()));
        if (aliasEntry) {
          namesToCompare.push(...aliasEntry.aliases);
        }

        for (const targetName of namesToCompare) {
          const matchScore = FuzzyMatchEngine.calculateMatchScore(cleanPhrase, targetName);
          if (matchScore > maxItemScore) {
            maxItemScore = matchScore;
          }
        }

        const weightedScore = maxItemScore * rankWeight;
        if (weightedScore > 0.30) {
          candidateScores.push({
            foodItem: item,
            score: weightedScore,
            rawText,
            cleanText: cleanPhrase
          });
        }
      });
    });

    const itemMap = new Map<string, { foodItem: FoodItem; score: number; rawText: string }>();
    candidateScores.forEach(cs => {
      const existing = itemMap.get(cs.foodItem.id);
      if (!existing || cs.score > existing.score) {
        itemMap.set(cs.foodItem.id, { foodItem: cs.foodItem, score: cs.score, rawText: cs.rawText });
      }
    });

    const sortedCandidates = Array.from(itemMap.values()).sort((a, b) => b.score - a.score);

    if (sortedCandidates.length === 0) {
      return {
        isMatched: false,
        matchedValue: null,
        confidence: 0,
        needsClarification: false,
        top3Candidates: catalog.slice(0, 3),
        quantity: globalQuantity
      };
    }

    const topCandidate = sortedCandidates[0];
    const catKey = genericCheck.categoryKey || primaryExt.cleanPhrase;
    const catLower = catKey.toLowerCase();
    const categoryVariants = catalog.filter(f => {
      const name = f.name.toLowerCase();
      const cat = f.category.toLowerCase();
      const tags = (f.tags || []).map(t => t.toLowerCase());
      return name.includes(catLower) || cat.includes(catLower) || tags.some(t => t.includes(catLower));
    });
    const top3Items = categoryVariants.length >= 1 ? categoryVariants : sortedCandidates.slice(0, 3).map(c => c.foodItem);

    // Rule 1: Generic Category Term Rule ("idli", "dosa", "biryani", "parotta")
    // If only 1 variant exists in catalog (e.g. "idli" -> Steamed Button Sambar Idli), auto-select it directly!
    // Never show "Which idli?" with a single button.
    // If 2 or more variants exist (e.g. "dosa" -> 4 variants), ask "Which {category} would you like?" with ALL variant buttons!
    if (genericCheck.isGeneric && sortedCandidates.length >= 1) {
      if (categoryVariants.length === 1) {
        return {
          isMatched: true,
          matchedValue: categoryVariants[0],
          confidence: Math.max(topCandidate.score, 0.90),
          needsClarification: false,
          bestCandidate: categoryVariants[0],
          top3Candidates: [categoryVariants[0]],
          matchedTranscript: topCandidate.rawText,
          quantity: globalQuantity,
          isGenericCategory: true
        };
      } else if (categoryVariants.length > 1) {
        const catName = genericCheck.categoryKey || primaryExt.cleanPhrase;
        const prompt = language === 'ta'
          ? `எந்த ${catName} உங்களுக்கு வேண்டும்?`
          : language === 'hi'
          ? `आपको कौन सा ${catName} चाहिए?`
          : `Which ${catName} would you like?`;

        return {
          isMatched: false,
          matchedValue: null,
          confidence: topCandidate.score,
          needsClarification: true,
          bestCandidate: topCandidate.foodItem,
          top3Candidates: categoryVariants,
          clarificationPrompt: prompt,
          matchedTranscript: topCandidate.rawText,
          quantity: globalQuantity,
          isGenericCategory: true
        };
      }
    }

    // Rule 2: High Confidence (>= 0.75) -> Auto-Proceed
    if (topCandidate.score >= FUZZY_CONFIG.highConfidence) {
      return {
        isMatched: true,
        matchedValue: topCandidate.foodItem,
        confidence: topCandidate.score,
        needsClarification: false,
        top3Candidates: top3Items,
        matchedTranscript: topCandidate.rawText,
        quantity: globalQuantity
      };
    }

    // Rule 3: Medium Confidence (0.45 <= score < 0.75) -> "Did you mean {Item}?" + Top 3 Buttons
    if (topCandidate.score >= FUZZY_CONFIG.mediumConfidence) {
      const topName = topCandidate.foodItem.nativeNames?.[language] || topCandidate.foodItem.name;
      const prompt = language === 'ta'
        ? `நீங்கள் "${topName}" என்று கூறினீர்களா?`
        : language === 'hi'
        ? `क्या आपका मतलब "${topName}" था?`
        : `Did you mean "${topName}"?`;

      return {
        isMatched: false,
        matchedValue: topCandidate.foodItem,
        confidence: topCandidate.score,
        needsClarification: true,
        bestCandidate: topCandidate.foodItem,
        top3Candidates: top3Items,
        clarificationPrompt: prompt,
        matchedTranscript: topCandidate.rawText,
        quantity: globalQuantity
      };
    }

    // Rule 4: Low Confidence (< 0.45) -> Top 3 candidate buttons / popular suggestions
    return {
      isMatched: false,
      matchedValue: null,
      confidence: topCandidate.score,
      needsClarification: false,
      top3Candidates: top3Items.length > 0 ? top3Items : catalog.slice(0, 3),
      matchedTranscript: topCandidate.rawText,
      quantity: globalQuantity
    };
  }

  public static matchLocation(
    transcripts: string | string[],
    language: Language = 'en'
  ): { isMatched: boolean; area: string; city: string; confidence: number } {
    const candidates = this.toCandidateList(transcripts);
    if (candidates.length === 0) {
      return { isMatched: false, area: '', city: '', confidence: 0 };
    }

    const LOCATION_PRESETS = [
      {
        city: 'Chennai',
        area: 'Anna Nagar',
        aliases: ['anna nagar', 'அண்ணா நகர்', 'अन्ना नगर', 'chennai anna nagar', 'சென்னை அண்ணா நகர்', 'சென்னை', 'chennai', 'चेन्नई', 'madras']
      },
      {
        city: 'Chennai',
        area: 'T. Nagar',
        aliases: ['t nagar', 't. nagar', 'thiagaraya nagar', 'தி நகர்', 'டி நகர்', 'टी नगर', 'chennai t nagar']
      },
      {
        city: 'Chennai',
        area: 'Velachery',
        aliases: ['velachery', 'வேளச்சேரி', 'वेलाचेरी', 'chennai velachery']
      },
      {
        city: 'Coimbatore',
        area: 'Gandhipuram',
        aliases: ['coimbatore', 'கோவை', 'கோயம்புத்தூர்', 'कोयंबटूर', 'gandhipuram', 'காந்திபுரம்', 'गांधीपुरम']
      },
      {
        city: 'Madurai',
        area: 'KK Nagar',
        aliases: ['madurai', 'மதுரை', 'मदुरै', 'kk nagar', 'கே கே நகர்', 'के के नगर']
      },
      {
        city: 'Salem',
        area: 'Fairlands',
        aliases: ['salem', 'சேலம்', 'सलेम', 'fairlands', 'பேர்லேண்ட்ஸ்', 'फेयरलैंड्स']
      },
      {
        city: 'Bengaluru',
        area: 'Indiranagar',
        aliases: ['bengaluru', 'bangalore', 'பெங்களூரு', 'பெங்களூர்', 'बेंगलुरु', 'बैंगलोर', 'indiranagar', 'இந்திரா நகர்', 'इंदिरानगर']
      },
      {
        city: 'Hyderabad',
        area: 'Gachibowli',
        aliases: ['hyderabad', 'ஹைதராபாத்', 'हैदराबाद', 'gachibowli', 'கச்சிபௌலி', 'गाचीबोवली']
      },
      {
        city: 'Mumbai',
        area: 'Bandra West',
        aliases: ['mumbai', 'bombay', 'மும்பை', 'பம்பாய்', 'मुंबई', 'बॉम्बे', 'bandra', 'பாந்த்ரா', 'बांद्रा']
      },
      {
        city: 'Delhi',
        area: 'Connaught Place',
        aliases: ['delhi', 'new delhi', 'டெல்லி', 'புது டெல்லி', 'दिल्ली', 'नई दिल्ली', 'connaught place', 'கன்னாட் பிளேஸ்', 'कनॉट प्लेस']
      }
    ];

    for (const cand of candidates) {
      const clean = cand.toLowerCase().trim();
      for (const loc of LOCATION_PRESETS) {
        for (const alias of loc.aliases) {
          if (clean === alias || clean.includes(alias) || alias.includes(clean)) {
            return {
              isMatched: true,
              area: loc.area,
              city: loc.city,
              confidence: 0.95
            };
          }
        }
      }
    }

    return { isMatched: false, area: '', city: '', confidence: 0 };
  }
}

