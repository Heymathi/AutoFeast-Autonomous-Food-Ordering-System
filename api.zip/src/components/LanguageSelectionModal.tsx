import React, { useEffect, useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Language } from '../types';
import { SpeechController } from '../services/speechController';
import { SttMatcherService } from '../services/sttMatcherService';
import { TRANSLATIONS } from '../data/translations';
import { Sparkles, Globe, Volume2, Mic, CheckCircle2, HelpCircle } from 'lucide-react';

export const LanguageSelectionModal: React.FC = () => {
  const {
    entryStep,
    isLanguageModalOpen,
    handleLanguageSelected,
    speakText,
    language: currentLanguage,
    setLanguage,
    currentUser,
    showToast,
    t
  } = useApp();

  const [isListening, setIsListening] = useState(false);
  const [selectedTemp, setSelectedTemp] = useState<Language | null>(currentLanguage || 'en');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [ttsBlocked, setTtsBlocked] = useState(false);
  const [userTapped, setUserTapped] = useState(false);
  const [displayedSentences, setDisplayedSentences] = useState<string[]>([]);
  const [mediumConfidencePrompt, setMediumConfidencePrompt] = useState<{ lang: Language; label: string } | null>(null);

  const hasStartedSequenceRef = useRef(false);
  const hasProceededRef = useRef(false);
  const hasRetriedRef = useRef(false);
  const activePromptsRef = useRef<string[]>([]);
  const isComponentMounted = useRef<boolean>(false);

  const ENGLISH_PROMPT = TRANSLATIONS.en['langModal.promptEn'];
  const TAMIL_PROMPT = TRANSLATIONS.ta['langModal.promptTa'];
  const HINDI_PROMPT = TRANSLATIONS.hi['langModal.promptHi'];

  useEffect(() => {
    isComponentMounted.current = true;
    return () => {
      isComponentMounted.current = false;
      cleanupSpeech();
    };
  }, []);

  useEffect(() => {
    if (currentLanguage) {
      setSelectedTemp(currentLanguage);
    }
  }, [currentLanguage]);

  useEffect(() => {
    if (entryStep === 'language' || isLanguageModalOpen) {
      hasProceededRef.current = false;
      hasStartedSequenceRef.current = false;
      hasRetriedRef.current = false;
      setDisplayedSentences([]);
      setMediumConfidencePrompt(null);
      setTtsBlocked(false);
      setUserTapped(false);
    } else {
      cleanupSpeech();
    }
  }, [entryStep, isLanguageModalOpen]);

  const cleanupSpeech = () => {
    SpeechController.cancelSpeech();
    SpeechController.releaseMic('language_selection');
    setIsListening(false);
  };

  /**
   * Sequential 3-Sentence TTS Prompting:
   * English -> Tamil -> Hindi
   * If ta/hi voice is missing, show sentence as text instead of speaking with English accent.
   */
  const startSequentialPromptSequence = () => {
    if (hasStartedSequenceRef.current || hasProceededRef.current) return;
    hasStartedSequenceRef.current = true;
    setUserTapped(true);

    const prompts: string[] = [];
    activePromptsRef.current = [ENGLISH_PROMPT, TAMIL_PROMPT, HINDI_PROMPT];

    // Sentence 1: English
    setDisplayedSentences([ENGLISH_PROMPT]);
    prompts.push(ENGLISH_PROMPT);

    SpeechController.speak(
      ENGLISH_PROMPT,
      'en',
      () => {
        if (!isComponentMounted.current || hasProceededRef.current) return;

        // Sentence 2: Tamil prompt spoken aloud
        setDisplayedSentences(prev => [...prev, TAMIL_PROMPT]);
        SpeechController.speak(
          TAMIL_PROMPT,
          'ta',
          () => {
            speakHindiSentenceAndOpenMic();
          },
          (fallbackMsg) => {
            console.log('[LanguageModal]: Tamil voice note:', fallbackMsg);
            speakHindiSentenceAndOpenMic();
          },
          'language_selection'
        );
      },
      (fallbackMsg) => {
        setTtsBlocked(true);
        console.warn('[LanguageModal]: English TTS blocked/failed:', fallbackMsg);
      },
      'language_selection'
    );
  };

  const speakHindiSentenceAndOpenMic = () => {
    if (!isComponentMounted.current || hasProceededRef.current) return;

    // Sentence 3: Hindi prompt spoken aloud
    setDisplayedSentences(prev => [...prev.filter(s => !s.includes(HINDI_PROMPT)), HINDI_PROMPT]);
    SpeechController.speak(
      HINDI_PROMPT,
      'hi',
      () => {
        scheduleMicAutoOpen();
      },
      (fallbackMsg) => {
        console.log('[LanguageModal]: Hindi voice note:', fallbackMsg);
        scheduleMicAutoOpen();
      },
      'language_selection'
    );
  };

  const scheduleMicAutoOpen = () => {
    if (!isComponentMounted.current || hasProceededRef.current) return;
    const timer = setTimeout(() => {
      if (isComponentMounted.current && !hasProceededRef.current) {
        startListeningForLanguage();
      }
    }, 300);
  };

  const startListeningForLanguage = () => {
    if (!SpeechController.isSupported() || hasProceededRef.current) return;

    setIsListening(true);

    SpeechController.requestMic({
      owner: 'language_selection',
      language: currentLanguage || 'en',
      continuous: false,
      interimResults: true,
      maxAlternatives: 5,
      onStart: () => {
        if (isComponentMounted.current) setIsListening(true);
      },
      onResult: (transcript, isFinal, nBestTranscripts) => {
        if (!transcript || hasProceededRef.current) return;
        setLiveTranscript(transcript);
        if (!isFinal) return;

        const candidates = nBestTranscripts && nBestTranscripts.length > 0 ? nBestTranscripts : [transcript];
        console.log('[LanguageSelection Voice Candidates]:', candidates);

        // Filter out app's own prompt echo text
        const isEcho = candidates.some(cand =>
          activePromptsRef.current.some(prompt => cand.toLowerCase().includes(prompt.toLowerCase().substring(0, 15)))
        );
        if (isEcho) {
          console.log('[LanguageSelectionModal]: Ignored prompt echo speech input.');
          return;
        }

        // Handle Medium Confidence Yes/No Confirmation if active
        if (mediumConfidencePrompt) {
          const matchConfirm = SttMatcherService.matchConfirmation(candidates, currentLanguage || 'en');
          if (matchConfirm.isMatched && matchConfirm.matchedValue === 'YES') {
            handleChooseLanguage(mediumConfidencePrompt.lang, true);
            setMediumConfidencePrompt(null);
            return;
          } else if (matchConfirm.isMatched && matchConfirm.matchedValue === 'NO') {
            setMediumConfidencePrompt(null);
            setLiveTranscript('');
            startSequentialPromptSequence();
            return;
          }
        }

        // Match language choice using shared SttMatcherService over all 5 candidates
        const matchResult = SttMatcherService.matchLanguageChoice(candidates);

        if (matchResult.isMatched && matchResult.matchedValue) {
          const matchedLang = matchResult.matchedValue;
          console.log(`[LanguageSelection STT Match]: Matched -> "${matchedLang}" (score: ${matchResult.confidence})`);

          if (matchResult.needsClarification || (matchResult.confidence >= 0.45 && matchResult.confidence < 0.75)) {
            // Medium confidence: Ask "Did you mean Tamil?"
            const langLabel = matchedLang === 'ta' ? 'Tamil' : matchedLang === 'hi' ? 'Hindi' : 'English';
            const askText = matchedLang === 'ta'
              ? 'தமிழ் மொழியைக் குறிக்கிறீர்களா?'
              : matchedLang === 'hi'
              ? 'क्या आपका मतलब हिंदी है?'
              : 'Did you mean English?';

            setMediumConfidencePrompt({ lang: matchedLang, label: langLabel });
            SpeechController.speak(askText, matchedLang, () => {
              if (isComponentMounted.current && !hasProceededRef.current) {
                startListeningForLanguage();
              }
            }, undefined, 'language_selection');
          } else {
            // High confidence >= 0.75: Select language directly
            handleChooseLanguage(matchedLang, true);
          }
        } else {
          // Low confidence < 0.45: Reprompt once then rely on interactive buttons
          if (!hasRetriedRef.current) {
            hasRetriedRef.current = true;
            const retryMsg = currentLanguage === 'ta'
              ? 'மன்னிக்கவும், புரியவில்லை. தமிழ், ஹிந்தி அல்லது ஆங்கிலம் என்று சொல்லவும்.'
              : currentLanguage === 'hi'
              ? 'क्षमा करें, समझ नहीं आया। हिंदी, तमिल या अंग्रेजी बोलें।'
              : 'Sorry, I did not catch that. Please say English, Tamil, or Hindi.';

            SpeechController.speak(retryMsg, currentLanguage || 'en', () => {
              if (isComponentMounted.current && !hasProceededRef.current) {
                startListeningForLanguage();
              }
            }, undefined, 'language_selection');
          }
        }
      },
      onError: (errCode) => {
        if (isComponentMounted.current) setIsListening(false);
        console.warn('[LanguageSelection Mic Error]:', errCode);
      },
      onEnd: () => {
        if (isComponentMounted.current) setIsListening(false);
      }
    });
  };

  const handleUserGesture = () => {
    if (!userTapped || !hasStartedSequenceRef.current) {
      startSequentialPromptSequence();
    }
  };

  const handleChooseLanguage = (lang: Language, isSpoken: boolean = false) => {
    if (hasProceededRef.current) return;
    hasProceededRef.current = true;

    cleanupSpeech();
    setSelectedTemp(lang);
    setLanguage(lang);

    const confirmMsg = lang === 'ta'
      ? 'தமிழ் மொழி தேர்ந்தெடுக்கப்பட்டது.'
      : lang === 'hi'
      ? 'हिंदी भाषा चुनी गई।'
      : 'English language selected.';

    showToast(confirmMsg, 'success');

    let safeTimer: NodeJS.Timeout | null = null;
    const doAdvance = () => {
      if (safeTimer) clearTimeout(safeTimer);
      handleLanguageSelected(lang);
    };

    SpeechController.speak(confirmMsg, lang, doAdvance, undefined, 'language_selection');
    safeTimer = setTimeout(doAdvance, 2500);
  };

  if (entryStep !== 'language' && !isLanguageModalOpen) return null;

  return (
    <div
      onClick={handleUserGesture}
      className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-lg animate-fade-in"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-xl bg-white text-[#1A1110] rounded-3xl shadow-2xl overflow-hidden border-4 border-[#FF5A1F] transition-all transform scale-100"
      >

        {/* Top Branding Banner */}
        <div className="bg-[#DAF0F7] p-6 text-center border-b border-[#B2E2F0]">
          <div className="inline-flex items-center justify-center p-3.5 bg-white rounded-2xl mb-3 shadow-md border border-[#B2E2F0]">
            <Sparkles className="w-8 h-8 text-[#FF5A1F] mr-2 animate-pulse" />
            <h1 className="text-3xl font-black text-[#1A1110] tracking-tight">AutoFeast AI</h1>
          </div>

          <p className="text-xs font-black text-[#FF5A1F] uppercase tracking-widest flex items-center justify-center gap-1">
            <Globe className="w-4 h-4" />
            <span>Select Your Preferred Language / மொழியைத் தேர்ந்தெடுக்கவும்</span>
          </p>

          <div className="mt-3 space-y-1 text-xs font-bold text-[#4A5568]">
            <p>🇬🇧 Say "English", "Tamil", or "Hindi"</p>
            <p>🇮🇳 "தமிழ்", "ஆங்கிலம்" அல்லது "ஹிந்தி" என்று சொல்லுங்கள்</p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="p-6 sm:p-8 space-y-4">

          {/* User Gesture Tap to Start Voice Button */}
          {!userTapped && (
            <button
              type="button"
              data-testid="btn-tap-start-voice"
              onClick={startSequentialPromptSequence}
              className="w-full p-4 bg-[#FF5A1F] hover:bg-[#E04812] text-white rounded-2xl font-black text-sm sm:text-base shadow-lg flex items-center justify-center space-x-2 cursor-pointer transition-transform active:scale-95 animate-pulse"
            >
              <Mic className="w-5 h-5 text-yellow-300" />
              <span>{t('langModal.tapToStart') || 'Tap to start voice assistant'}</span>
            </button>
          )}

          {/* Displayed Sentences / Spoken Prompts */}
          {displayedSentences.length > 0 && (
            <div className="p-3 bg-[#DAF0F7]/50 rounded-2xl border border-[#B2E2F0] space-y-1">
              <span className="text-[10px] font-black uppercase text-[#FF5A1F] flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5" /> Spoken Prompts:
              </span>
              {displayedSentences.map((sent, idx) => (
                <p key={idx} className="text-xs font-bold text-[#1A1110]">{sent}</p>
              ))}
            </div>
          )}

          {/* Medium Confidence "Did You Mean" Confirmation Card */}
          {mediumConfidencePrompt && (
            <div className="p-4 bg-amber-50 border-2 border-amber-400 rounded-2xl space-y-3 shadow-md animate-fade-in text-center">
              <div className="flex items-center justify-center space-x-2 text-amber-900 font-black text-sm">
                <HelpCircle className="w-5 h-5 text-[#FF5A1F]" />
                <span>Did you mean {mediumConfidencePrompt.label}?</span>
              </div>
              <p className="text-xs text-amber-800 font-bold">Say "Yes" or "No", or tap below:</p>
              <div className="flex items-center justify-center gap-3">
                <button
                  type="button"
                  data-testid="btn-confirm-did-you-mean-yes"
                  onClick={() => handleChooseLanguage(mediumConfidencePrompt.lang, true)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-sm cursor-pointer"
                >
                  Yes, select {mediumConfidencePrompt.label}
                </button>
                <button
                  type="button"
                  data-testid="btn-confirm-did-you-mean-no"
                  onClick={() => {
                    setMediumConfidencePrompt(null);
                    setLiveTranscript('');
                    startSequentialPromptSequence();
                  }}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-black text-xs rounded-xl shadow-sm cursor-pointer"
                >
                  No, try again
                </button>
              </div>
            </div>
          )}

          {/* Voice Status Badge */}
          <div className="flex items-center justify-between p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-xs shadow-xs">
            <div className="flex items-center space-x-2">
              <Volume2 className="w-5 h-5 text-[#FF5A1F] animate-bounce shrink-0" />
              <span className="font-extrabold text-[#1A1110]">
                {liveTranscript
                  ? `🎙️ Spoken: "${liveTranscript}"`
                  : isListening
                  ? '🎙️ Listening... Say "Tamil", "English", or "Hindi"'
                  : '🔊 Speak or tap your preferred language'}
              </span>
            </div>
            <button
              type="button"
              onClick={startSequentialPromptSequence}
              className="px-3 py-1.5 bg-[#FF5A1F] text-white rounded-xl font-bold flex items-center space-x-1 shadow-xs hover:bg-[#E04812] cursor-pointer shrink-0"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Voice</span>
            </button>
          </div>

          {/* 3 Interactive Language Cards (Tap or Voice Fallback) */}
          <div className="grid grid-cols-1 gap-3 pt-1">

            {/* Option 1: Tamil */}
            <button
              type="button"
              data-testid="btn-select-language-ta"
              onClick={() => handleChooseLanguage('ta')}
              className={`p-4 rounded-2xl border-3 flex items-center justify-between transition-all cursor-pointer text-left ${
                selectedTemp === 'ta' || currentLanguage === 'ta'
                  ? 'border-[#FF5A1F] bg-[#FF5A1F]/10 shadow-lg scale-102'
                  : 'border-[#DAF0F7] bg-slate-50 hover:bg-[#DAF0F7]/40 hover:border-[#B2E2F0]'
              }`}
            >
              <div className="flex items-center space-x-4">
                <span className="text-3xl">🇮🇳</span>
                <div>
                  <h3 className="text-lg font-black text-[#1A1110]">தமிழ் (Tamil)</h3>
                  <p className="text-xs font-bold text-[#4A5568]">முழுமையான குரல் வழி வழிகாட்டுதலுடன் தமிழ்</p>
                </div>
              </div>
              <div className="p-2 bg-white rounded-full border border-slate-200">
                <CheckCircle2 className={`w-5 h-5 ${selectedTemp === 'ta' ? 'text-[#FF5A1F]' : 'text-slate-300'}`} />
              </div>
            </button>

            {/* Option 2: English */}
            <button
              type="button"
              data-testid="btn-select-language-en"
              onClick={() => handleChooseLanguage('en')}
              className={`p-4 rounded-2xl border-3 flex items-center justify-between transition-all cursor-pointer text-left ${
                selectedTemp === 'en' || currentLanguage === 'en'
                  ? 'border-[#FF5A1F] bg-[#FF5A1F]/10 shadow-lg scale-102'
                  : 'border-[#DAF0F7] bg-slate-50 hover:bg-[#DAF0F7]/40 hover:border-[#B2E2F0]'
              }`}
            >
              <div className="flex items-center space-x-4">
                <span className="text-3xl">🇬🇧</span>
                <div>
                  <h3 className="text-lg font-black text-[#1A1110]">English</h3>
                  <p className="text-xs font-bold text-[#4A5568]">Full English voice assistance & natural interaction</p>
                </div>
              </div>
              <div className="p-2 bg-white rounded-full border border-slate-200">
                <CheckCircle2 className={`w-5 h-5 ${selectedTemp === 'en' ? 'text-[#FF5A1F]' : 'text-slate-300'}`} />
              </div>
            </button>

            {/* Option 3: Hindi */}
            <button
              type="button"
              data-testid="btn-select-language-hi"
              onClick={() => handleChooseLanguage('hi')}
              className={`p-4 rounded-2xl border-3 flex items-center justify-between transition-all cursor-pointer text-left ${
                selectedTemp === 'hi' || currentLanguage === 'hi'
                  ? 'border-[#FF5A1F] bg-[#FF5A1F]/10 shadow-lg scale-102'
                  : 'border-[#DAF0F7] bg-slate-50 hover:bg-[#DAF0F7]/40 hover:border-[#B2E2F0]'
              }`}
            >
              <div className="flex items-center space-x-4">
                <span className="text-3xl">🇮🇳</span>
                <div>
                  <h3 className="text-lg font-black text-[#1A1110]">हिन्दी (Hindi)</h3>
                  <p className="text-xs font-bold text-[#4A5568]">पूर्ण आवाज सहायता के साथ हिंदी भाषा</p>
                </div>
              </div>
              <div className="p-2 bg-white rounded-full border border-slate-200">
                <CheckCircle2 className={`w-5 h-5 ${selectedTemp === 'hi' ? 'text-[#FF5A1F]' : 'text-slate-300'}`} />
              </div>
            </button>

          </div>

        </div>

      </div>
    </div>
  );
};
